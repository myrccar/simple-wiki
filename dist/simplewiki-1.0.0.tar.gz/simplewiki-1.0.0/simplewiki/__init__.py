from simplewiki.wiki import wikipedia
__all__ = ["wikipedia"]