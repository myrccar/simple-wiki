# simple wiki WIP

a simple warper for the wikipedia api 

